import { ShopEffects } from "./shop.effect";

export const effects: any[] = [ShopEffects];

export * from "./shop.effect";
